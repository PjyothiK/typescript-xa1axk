let someVar:string | number = '4';
if(typeof(someVar) === 'string') //use typeof for Primitives
    console.log(`String : ${someVar}`);
else
    console.log(`Number : ${someVar}`);

//class (instanceof)

class Employee{
    doWork(){
        console.log('Employee will do the work');
    }
}

class Manager{
    manage(){
        console.log('Manage Employees');
    }
}

let workObj: Employee | Manager;
workObj = new Manager();
if(workObj instanceof Employee){
    workObj.doWork();
}

if(workObj instanceof Manager){
    workObj.manage();
}

//Interface (userdefined typeGuards)
interface IVehicle{
    numberOfWheels:number
}
let isVehicle = (obj:any) : obj is IVehicle =>{
    return (<IVehicle>obj).numberOfWheels !== undefined;
}


let car = {numberOfWheels:4,test:5}
if(isVehicle(car)){
    console.log('It is a Vehicle')
}else{
    console.log('It is not a Vehicle')
}

