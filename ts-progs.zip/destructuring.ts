let cities:string[] = ['Bangalore','Chennai','Mumbai'];
/*let firstCity:string = cities[0];
let secondCity:string = cities[1];
let thirdCity:string = cities[2];
 */

//Destructing Array
let [firstCity,secondCity,thirdCity] = cities;

let person = {
    id:108331,
    personName:'Karthik'
}
/*let employeeId : number= employee.id;
let employeeName:string= employee['name'];
*/
//Destructuring Object
let {id,personName} = person;
console.log(id);
console.log(personName);


