/*Union Types*/
let test = (data: string | number | boolean): string | boolean | number => {
    if (typeof (data) == 'string')
        return `String = ${data}`;
    else if (typeof (data) == 'number')
        return `Number = ${data}`;
    else
        return `Boolean = ${data}`;
}

console.log(test(5));
console.log(test('Karthik'));
console.log(test(false));
