/*ES5*/
var add = function (a, b) {
    return a + b;
};
var addResult = add(5, 6);
/*ES6-Arrow Function*/
var addNumbers = function (a, b) { return a + b; };
/*TypeScript-Arrow Function*/
var addition = function (a, b) { return a + b; };
(function () {
    this.counter = 0;
    setInterval(()=> {
        console.log("Counter = ".concat(this.counter++));
    }, 1000);
})();
