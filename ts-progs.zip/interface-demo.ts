/*To Define an Object */
interface IEmployee{
    id:number,
    name:string,
    department?:string;
}

let sampleFn = (employee:IEmployee)=>{
    console.log(`Id = ${employee.id} Name = ${employee.name}`);
}
sampleFn({id:5,name:'Karthik'});

interface IGreetable{
    language:string;
    greet(message:string):void;
    createError():void
}

class Greet implements IGreetable{
    language: string = 'English';

    greet(message: string): void {
        console.log(`Message : ${message}`);
    }

    createError(): void {
        throw 'Custom Error'
    }
}

let greetObj:Greet = new Greet();
try {
    greetObj.greet('Welcome');
    greetObj.createError();
} catch (err) {
    console.log(err);   
}