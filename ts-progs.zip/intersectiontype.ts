interface Person{
    name:string;
}

interface Employee{
    id:number;
}

let personEmployee = (obj:Employee & Person) : Employee & Person=>{
    return {id:obj.id , name: obj.name}
}
console.log(personEmployee({id:10,name:'Karthik'}));
