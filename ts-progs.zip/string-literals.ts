let direction : 'WEST' | 'NORTH' |'EAST' | 'SOUTH';
direction = 'WEST'; //Allowed
direction = 'west'; //Not Allowed
