let firstName:string = 'Karthik';
let lastName:string = 'Muthukrishnan';
let fullName:string = `${firstName} ${lastName}`;
let multiLine = `Hi
                Everyone
                Welcome to TypeScript`;
console.log(fullName);
console.log(multiLine);
