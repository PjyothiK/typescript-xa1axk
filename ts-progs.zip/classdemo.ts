class Foo{
    private id:number;
    private name:string;

    constructor(id:number,name:string){
        this.id = id;
        this.name = name;
    }
    printFooDetails():string{
        return `Id = ${this.id} Name = ${this.name}`
    }
}
let fooObj:Foo = new Foo(1,'Karthik');
console.log(fooObj.printFooDetails());