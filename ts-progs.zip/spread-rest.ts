let sample = (a:number,b:number,...args:number[])=>{ //Rest operator
    console.log(a);
    console.log(b);
    console.log(args);
    
}

sample(3,6,4,6,7,3,6);
//sample(5,6,[23,6,3]) //Incorrect
let numbers = [23,6,3];
sample(5,6,...numbers); //Spread Operator
