let test = (firstName:string,middleName:string='Default Middle',lastName?:string)=>{
    if(lastName !== undefined && middleName != ' '){
        console.log(`${firstName} ${middleName} ${lastName}`);
    }
    else if(middleName == ' ')
    {
        console.log(`${firstName} ${lastName}`);
    }
    else{
        console.log(`${firstName} ${middleName}`);
    }
}
test('John');
test('Karthik',' ','Muthukrishnan');
test('Ashik','Mohmmad','Ibrahim');


