let numberLet:number = 5;
let stringLet:string = '5';
let booleanLet:boolean = true;
let numbers:number[] = [5,6];
let numberList:Array<number> = [89,43];

enum Direction {NORTH,EAST,WEST,SOUTH};
let directions:Direction = Direction.NORTH;

let addNumbers = (a:number,b:number):void=>{
    console.log(a+b);

}
addNumbers(5,6);


