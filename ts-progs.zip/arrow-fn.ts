/*ES5*/
/*var add = function(a,b){
    return a + b;
} */
//var addResult = add(5,6);

/*(function(){
  this.counter = 0;
  setInterval(function(){
    console.log(`Counter = ${this.counter++}`);
  },1000)
})();*/

/*ES6-Arrow Function*/
//var addNumbers= (a,b)=> a + b;

/*TypeScript-Arrow Function*/
var addition = (a:number,b:number):number=> a + b;
console.log(addition(5,6));




